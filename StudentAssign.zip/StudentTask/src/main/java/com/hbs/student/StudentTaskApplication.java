package com.hbs.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentTaskApplication.class, args);
	}

}
