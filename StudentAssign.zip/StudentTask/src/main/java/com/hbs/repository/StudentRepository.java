package com.hbs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hbs.entities.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {


}
